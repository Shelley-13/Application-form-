var selectedRow= null;

function onFormSubmit(){
    validation();
    var formData=readFormData();
    if (selectedRow == null){
        insertNewRecord(formData);}
    else{
        updateRecord(formData);
    }
    resetform();
}

function validation(){
    let name= document.getElementById("Name").value;
    let email= document.getElementById("Email").value;
    let contact= document.getElementById("Contact").value;
    let weekday= document.getElementById("Day").value;
    let gender= document.getElementsByName("Gender").value;
    let date= document.getElementById("Date").value;
    if(name=="" || email=="" || contact=="" || weekday=="" || gender=="" || date==""){
        alert("Please fill all the fields in the application");
    }
}

function readFormData(){
    var formData={};
    formData["Name"]=document.getElementById("Name").value;
    formData["Email"]=document.getElementById("Email").value;
    formData["Contact"]=document.getElementById("Contact").value;
    formData["Day"]=document.querySelector("input[name='Week']:checked").value;
    formData["Gender"]=document.querySelector("input[name='Gender']:checked").value;
    formData["Date"]=document.getElementById("Date").value;
        return formData;
}

function insertNewRecord(data){
    var records= document.getElementById("apptable").getElementsByTagName("tbody")[0];
    var newrow= records.insertRow(records.length);
    cell1= newrow.insertCell(0);
    cell1.innerHTML= data.Name;
    cell2= newrow.insertCell(1);
    cell2.innerHTML= data.Contact;
    cell3= newrow.insertCell(2);
    cell3.innerHTML= data.Email;
    cell4= newrow.insertCell(3);
    cell4.innerHTML= data.Day;
    cell5= newrow.insertCell(4);
    cell5.innerHTML= data.Gender;
    cell6= newrow.insertCell(5);
    cell6.innerHTML= data.Date; 
    cell7= newrow.insertCell(6);
    cell7.innerHTML=`<button onClick="onEdit(this)">Edit</button>
                        <button onClick="onDelete(this)">Delete</button>`;
}

function resetform(){
    document.getElementById("form").reset();
    selectedRow=null;
}

function onEdit(td){
    selectedRow=td.parentElement.parentElement;
    document.getElementById("Name").value=selectedRow.cells[0].innerHTML;
    document.getElementById("Contact").value=selectedRow.cells[1].innerHTML;
    document.getElementById("Email").value=selectedRow.cells[2].innerHTML;
    //document.querySelector("input[name='Week']:checked").value= selectedRow.cells[3].innerHTML;
    //document.querySelector("input[name='Gender']:checked").value=selectedRow.cells[4].innerHTML;
    //document.getElementById("Date").value=selectedRow.cells[5].innerHTML;
}

function updateRecord(formData){
    if(confirm("Are you sure you want to update this data?")){
        selectedRow.cells[0].innerHTML = formData.Name;
        selectedRow.cells[1].innerHTML = formData.Email;
        selectedRow.cells[2].innerHTML = formData.Contact;
        selectedRow.cells[3].innerHTML = formData.Day;
        selectedRow.cells[4].innerHTML = formData.Gender;
        selectedRow.cells[5].innerHTML = formData.Date;
    }
}

function onDelete(td){
    if (confirm("Are you sure you want to delete this record?")){
        row= td.parentElement.parentElement;
        document.getElementById("apptable").deleteRow(row.rowIndex);
        resetform();
}
}
